# pwatarea3 – Tarea 3: HTML, CSS, JavaScript y PHP

| Directorio | Ejercicio |
|---|---|
| `index.php` | Presentación y menú con enlaces a todos los ejercicios |
| `ejercicio01/` | Menú desplegable |
| `ejercicio02/` | Formulario de contacto con validación JS y PHP |
| `ejercicio03/` | Contador de visitas (variable global + archivo) |
| `ejercicio04/` | Juego de adivinanzas (PHP + JS) |
| `ejercicio05/` | Galería de imágenes (PHP lee `imagenes/`) |
| `ejercicio06/` | Login con sesiones (arreglo de usuarios; MySQL opcional en `config.php`) |

Usuarios de prueba (ejercicio 6): `admin / admin123` · `maria / maria2024`.
Ejecutar local: `php -S localhost:8000` dentro de esta carpeta.
