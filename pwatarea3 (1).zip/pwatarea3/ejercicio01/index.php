<?php
// Los datos del menú los define PHP; HTML los muestra, CSS los estiliza y JS los despliega.
$menu = [
  'Inicio'    => ['Presentación', 'Novedades', 'Contacto'],
  'Productos' => ['Laptops', 'Teléfonos', 'Accesorios', 'Ofertas'],
  'Servicios' => ['Soporte técnico', 'Capacitación', 'Consultoría'],
  'Nosotros'  => ['Misión', 'Visión', 'Equipo'],
];
?>
<!DOCTYPE html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Ejercicio 1 – Menú desplegable</title>
<link rel="stylesheet" href="style.css"></head>
<body><div class="wrap">
<a class="back" href="../">← Volver al inicio</a>
<h1>Ejercicio 1 · Menú desplegable</h1>
<p class="sub">Haz clic en un elemento principal para mostrar u ocultar sus opciones.</p>
<nav class="menu card" id="menu">
  <ul>
  <?php foreach ($menu as $principal => $opciones): ?>
    <li class="menu-item">
      <button class="menu-btn" aria-expanded="false"><?= htmlspecialchars($principal) ?> <span class="flecha">▾</span></button>
      <ul class="submenu">
        <?php foreach ($opciones as $op): ?><li><a href="#"><?= htmlspecialchars($op) ?></a></li><?php endforeach; ?>
      </ul>
    </li>
  <?php endforeach; ?>
  </ul>
</nav>
<p id="estado" class="sub" style="margin-top:16px">Ninguna opción seleccionada.</p>
</div>
<script src="script.js"></script></body></html>
