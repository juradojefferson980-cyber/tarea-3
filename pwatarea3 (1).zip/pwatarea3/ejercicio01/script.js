// Las opciones adicionales están ocultas (CSS) y se muestran al hacer clic en el elemento principal.
const botones = document.querySelectorAll('.menu-btn');
const estado = document.getElementById('estado');

function cerrarTodos(excepto) {
  document.querySelectorAll('.menu-item').forEach(item => {
    if (item === excepto) return;
    item.querySelector('.submenu').classList.remove('abierto');
    item.querySelector('.menu-btn').setAttribute('aria-expanded', 'false');
  });
}

botones.forEach(btn => btn.addEventListener('click', e => {
  const item = btn.parentElement;
  const sub = item.querySelector('.submenu');
  cerrarTodos(item);
  const abierto = sub.classList.toggle('abierto');
  btn.setAttribute('aria-expanded', abierto);
  e.stopPropagation();
}));

document.querySelectorAll('.submenu a').forEach(a => a.addEventListener('click', e => {
  e.preventDefault();
  estado.textContent = 'Seleccionaste: ' + a.textContent;
  cerrarTodos(null);
}));

document.addEventListener('click', () => cerrarTodos(null));
