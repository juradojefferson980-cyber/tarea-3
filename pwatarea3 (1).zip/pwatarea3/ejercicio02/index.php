<?php
// Validación del lado del servidor (respaldo de la validación JS).
$errores = []; $enviado = false; $v = ['nombre'=>'','correo'=>'','mensaje'=>''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  foreach ($v as $k => $_) $v[$k] = trim($_POST[$k] ?? '');
  if ($v['nombre'] === '' || mb_strlen($v['nombre']) < 3) $errores['nombre'] = 'Ingresa tu nombre (mínimo 3 caracteres).';
  if (!filter_var($v['correo'], FILTER_VALIDATE_EMAIL))   $errores['correo'] = 'Ingresa un correo electrónico válido.';
  if (mb_strlen($v['mensaje']) < 10)                      $errores['mensaje'] = 'El mensaje debe tener al menos 10 caracteres.';
  if (!$errores) $enviado = true; // Aquí se podría usar mail() o guardar en una base de datos.
}
$h = fn($s) => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Ejercicio 2 – Formulario de contacto</title><link rel="stylesheet" href="style.css"></head>
<body><div class="wrap">
<a class="back" href="../">← Volver al inicio</a>
<h1>Ejercicio 2 · Formulario de contacto</h1>
<p class="sub">Todos los campos son obligatorios.</p>
<div class="card">
<?php if ($enviado): ?>
  <h2 class="ok">¡Mensaje enviado!</h2>
  <p>Gracias, <strong><?= $h($v['nombre']) ?></strong>. Te responderemos a <strong><?= $h($v['correo']) ?></strong>.</p>
  <p><em>“<?= nl2br($h($v['mensaje'])) ?>”</em></p>
  <a class="btn" style="text-decoration:none;display:inline-block" href="./">Enviar otro</a>
<?php else: ?>
<form id="form" method="post" novalidate>
  <label for="nombre">Nombre</label>
  <input id="nombre" name="nombre" type="text" value="<?= $h($v['nombre']) ?>">
  <small class="err" id="e-nombre"><?= $errores['nombre'] ?? '' ?></small>
  <label for="correo">Correo electrónico</label>
  <input id="correo" name="correo" type="email" value="<?= $h($v['correo']) ?>">
  <small class="err" id="e-correo"><?= $errores['correo'] ?? '' ?></small>
  <label for="mensaje">Mensaje</label>
  <textarea id="mensaje" name="mensaje" rows="5"><?= $h($v['mensaje']) ?></textarea>
  <small class="err" id="e-mensaje"><?= $errores['mensaje'] ?? '' ?></small>
  <p><button class="btn" type="submit">Enviar</button></p>
</form>
<?php endif; ?>
</div></div>
<script src="script.js"></script></body></html>
