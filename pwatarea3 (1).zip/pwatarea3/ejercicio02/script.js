// Validación por campo y de campos llenos antes de enviar.
const form = document.getElementById('form');
if (form) {
  const reglas = {
    nombre:  v => v.length >= 3 ? '' : 'Ingresa tu nombre (mínimo 3 caracteres).',
    correo:  v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? '' : 'Ingresa un correo electrónico válido.',
    mensaje: v => v.length >= 10 ? '' : 'El mensaje debe tener al menos 10 caracteres.',
  };
  function validar(campo) {
    const el = form.elements[campo];
    const msg = el.value.trim() === '' ? 'Este campo es obligatorio.' : reglas[campo](el.value.trim());
    document.getElementById('e-' + campo).textContent = msg;
    el.classList.toggle('invalido', !!msg);
    el.classList.toggle('valido', !msg);
    return !msg;
  }
  Object.keys(reglas).forEach(c => form.elements[c].addEventListener('input', () => validar(c)));
  form.addEventListener('submit', e => {
    const ok = Object.keys(reglas).map(validar).every(Boolean);
    if (!ok) e.preventDefault();
  });
}
