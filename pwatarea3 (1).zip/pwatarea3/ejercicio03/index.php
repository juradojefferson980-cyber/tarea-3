<?php
// Variable global que almacena el número de visitas.
$visitas = 0;
$archivo = __DIR__ . '/contador.txt';

function actualizar_visitas(string $archivo): void {
  global $visitas;                       // se usa la variable global
  $fp = fopen($archivo, 'c+');           // se crea si no existe
  flock($fp, LOCK_EX);                   // evita conflictos entre visitas simultáneas
  $visitas = (int) trim(stream_get_contents($fp));
  $visitas++;                            // +1 por cada visita
  ftruncate($fp, 0); rewind($fp);
  fwrite($fp, (string) $visitas);
  flock($fp, LOCK_UN); fclose($fp);
}
actualizar_visitas($archivo);
?>
<!DOCTYPE html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Ejercicio 3 – Contador de visitas</title><link rel="stylesheet" href="style.css"></head>
<body><div class="wrap">
<a class="back" href="../">← Volver al inicio</a>
<h1>Ejercicio 3 · Contador de visitas</h1>
<p class="sub">Cada vez que se carga esta página, el contador aumenta.</p>
<div class="card contador"><span>Visitas a este sitio</span><strong id="num"><?= number_format($visitas) ?></strong></div>
<p class="sub">Recarga la página (F5) para ver cómo cambia.</p>
</div><script src="script.js"></script></body></html>
