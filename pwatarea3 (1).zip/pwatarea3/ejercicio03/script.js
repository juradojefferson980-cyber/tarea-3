// Animación de conteo desde 0 hasta el valor entregado por PHP.
const el = document.getElementById('num');
const meta = parseInt(el.textContent.replace(/\D/g, ''), 10) || 0;
const inicio = performance.now(), dur = 800;
function paso(t) {
  const p = Math.min((t - inicio) / dur, 1);
  el.textContent = Math.round(meta * p).toLocaleString('es');
  if (p < 1) requestAnimationFrame(paso);
}
if (meta > 1) requestAnimationFrame(paso);
