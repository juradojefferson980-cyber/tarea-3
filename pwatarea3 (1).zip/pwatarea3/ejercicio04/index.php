<?php
session_start();
const MIN = 1, MAX = 100;

// Endpoint JSON usado por JavaScript.
if (isset($_GET['accion'])) {
  header('Content-Type: application/json; charset=utf-8');
  if ($_GET['accion'] === 'nuevo' || !isset($_SESSION['secreto'])) {
    $_SESSION['secreto'] = random_int(MIN, MAX);   // número aleatorio = respuesta
    $_SESSION['intentos'] = 0;
    if ($_GET['accion'] === 'nuevo') { echo json_encode(['ok' => true]); exit; }
  }
  if ($_GET['accion'] === 'adivinar') {
    $n = filter_var($_POST['numero'] ?? null, FILTER_VALIDATE_INT);
    if ($n === false || $n < MIN || $n > MAX) {
      echo json_encode(['estado' => 'invalido', 'mensaje' => "Ingresa un número entre " . MIN . " y " . MAX . "."]); exit;
    }
    $_SESSION['intentos']++;
    $s = $_SESSION['secreto'];
    if ($n === $s) echo json_encode(['estado' => 'acierto', 'intentos' => $_SESSION['intentos'], 'mensaje' => "¡Correcto! Era el $s. Lo lograste en {$_SESSION['intentos']} intento(s)."]);
    else echo json_encode(['estado' => 'fallo', 'intentos' => $_SESSION['intentos'], 'mensaje' => $n < $s ? "El número es MAYOR que $n. ¡Intenta otra vez!" : "El número es MENOR que $n. ¡Intenta otra vez!"]);
    exit;
  }
}
if (!isset($_SESSION['secreto'])) { $_SESSION['secreto'] = random_int(MIN, MAX); $_SESSION['intentos'] = 0; }
?>
<!DOCTYPE html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Ejercicio 4 – Juego de adivinanzas</title><link rel="stylesheet" href="style.css"></head>
<body><div class="wrap">
<a class="back" href="../">← Volver al inicio</a>
<h1>Ejercicio 4 · Adivina el número</h1>
<p class="sub">Piensa en un número entre <?= MIN ?> y <?= MAX ?>. Tienes intentos ilimitados.</p>
<div class="card">
  <form id="juego"><label for="numero">Tu número</label>
  <input id="numero" type="number" min="<?= MIN ?>" max="<?= MAX ?>" required autofocus>
  <p><button class="btn" type="submit">Adivinar</button> <button class="btn" type="button" id="nuevo" style="background:#475569;color:#e2e8f0">Nuevo juego</button></p></form>
  <p id="msg" class="msg" aria-live="polite"></p>
  <p class="sub">Intentos: <strong id="intentos">0</strong></p>
</div></div>
<script src="script.js"></script></body></html>
