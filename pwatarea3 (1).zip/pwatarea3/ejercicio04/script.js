// JavaScript envía el intento a PHP (fetch) y muestra la respuesta sin recargar.
const form = document.getElementById('juego');
const input = document.getElementById('numero');
const msg = document.getElementById('msg');
const intentos = document.getElementById('intentos');

form.addEventListener('submit', async e => {
  e.preventDefault();
  const r = await fetch('?accion=adivinar', { method: 'POST', body: new URLSearchParams({ numero: input.value }) });
  const d = await r.json();
  msg.textContent = d.mensaje;
  msg.className = 'msg ' + d.estado;
  if (d.intentos !== undefined) intentos.textContent = d.intentos;
  if (d.estado === 'acierto') { input.disabled = true; }
  else { input.select(); }
});

document.getElementById('nuevo').addEventListener('click', async () => {
  await fetch('?accion=nuevo');
  msg.textContent = ''; msg.className = 'msg'; intentos.textContent = '0';
  input.disabled = false; input.value = ''; input.focus();
});
