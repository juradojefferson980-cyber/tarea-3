<?php
// PHP carga las imágenes del directorio "imagenes" y arma la lista HTML.
$dir = __DIR__ . '/imagenes';
$imagenes = glob($dir . '/*.{jpg,jpeg,png,gif,webp,svg}', GLOB_BRACE) ?: [];
sort($imagenes);
function titulo(string $ruta): string {
  $n = pathinfo($ruta, PATHINFO_FILENAME);
  return ucfirst(str_replace(['-', '_'], ' ', preg_replace('/^\d+[-_]?/', '', $n)));
}
?>
<!DOCTYPE html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Ejercicio 5 – Galería de imágenes</title><link rel="stylesheet" href="style.css"></head>
<body><div class="wrap">
<a class="back" href="../">← Volver al inicio</a>
<h1>Ejercicio 5 · Galería de imágenes</h1>
<p class="sub"><?= count($imagenes) ?> imágenes cargadas desde el directorio <code>imagenes/</code>. Agrega más archivos y aparecerán solos.</p>
<ul class="galeria">
<?php foreach ($imagenes as $img): $f = basename($img); ?>
  <li><a href="imagenes/<?= rawurlencode($f) ?>" target="_blank"><img src="imagenes/<?= rawurlencode($f) ?>" alt="<?= htmlspecialchars(titulo($f)) ?>" loading="lazy"><span><?= htmlspecialchars(titulo($f)) ?></span></a></li>
<?php endforeach; ?>
<?php if (!$imagenes): ?><li class="card">No hay imágenes en el directorio.</li><?php endif; ?>
</ul></div></body></html>
