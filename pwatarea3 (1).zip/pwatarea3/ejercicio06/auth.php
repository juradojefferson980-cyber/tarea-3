<?php
require __DIR__ . '/config.php';
session_start();

// Arreglo de usuarios (las claves se guardan como hash, nunca en texto plano).
$usuarios = [
  'admin' => ['nombre' => 'Administrador', 'clave_hash' => '$2y$10$tkqckzhUkhQe.2kmWAZndOVaKw9BihlzkhtEAXG27v//oUvo8gTmS'],   // admin123
  'maria' => ['nombre' => 'María Pérez',   'clave_hash' => '$2y$10$zjWDvnyeLTp5yVogJI7Go.GBi2UvsHg0xBvtiXchy96qxW/npj7nq'],   // maria2024
];

function buscar_usuario(string $usuario): ?array {
  global $usuarios;
  if (USAR_MYSQL) {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS,
                   [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $st = $pdo->prepare('SELECT nombre, clave_hash FROM usuarios WHERE usuario = ?');
    $st->execute([$usuario]);
    return $st->fetch(PDO::FETCH_ASSOC) ?: null;
  }
  return $usuarios[$usuario] ?? null;
}

function iniciar_sesion(string $usuario, string $clave): bool {
  $u = buscar_usuario($usuario);
  if ($u && password_verify($clave, $u['clave_hash'])) {
    session_regenerate_id(true);
    $_SESSION['usuario'] = $usuario;
    $_SESSION['nombre'] = $u['nombre'];
    return true;
  }
  return false;
}

// Verifica si el usuario está autenticado.
function esta_autenticado(): bool { return isset($_SESSION['usuario']); }
