<?php
// false = usuarios en un arreglo PHP (funciona sin base de datos).
// true  = usuarios en MySQL (importar schema.sql y completar los datos).
const USAR_MYSQL = false;
const DB_HOST = 'localhost';
const DB_NAME = 'pwatarea3';
const DB_USER = 'root';
const DB_PASS = '';
