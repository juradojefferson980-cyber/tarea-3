<?php
require __DIR__ . '/auth.php';
if (!esta_autenticado()) { header('Location: login.php'); exit; }   // página protegida
?>
<!DOCTYPE html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Ejercicio 6 – Área privada</title><link rel="stylesheet" href="style.css"></head>
<body><div class="wrap">
<a class="back" href="../">← Volver al inicio</a>
<h1>Área privada</h1>
<div class="card">
  <h2 class="ok">Bienvenido, <?= htmlspecialchars($_SESSION['nombre']) ?></h2>
  <p>Has iniciado sesión como <strong><?= htmlspecialchars($_SESSION['usuario']) ?></strong>. Esta página solo se muestra a usuarios autenticados.</p>
  <a class="btn" style="text-decoration:none;display:inline-block" href="logout.php">Cerrar sesión</a>
</div></div></body></html>
