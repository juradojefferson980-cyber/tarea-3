<?php
require __DIR__ . '/auth.php';
if (esta_autenticado()) { header('Location: ./'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $usuario = trim($_POST['usuario'] ?? ''); $clave = $_POST['clave'] ?? '';
  if ($usuario === '' || $clave === '') $error = 'Completa usuario y contraseña.';
  elseif (iniciar_sesion($usuario, $clave)) { header('Location: ./'); exit; }
  else $error = 'Usuario o contraseña incorrectos.';
}
?>
<!DOCTYPE html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Ejercicio 6 – Iniciar sesión</title><link rel="stylesheet" href="style.css"></head>
<body><div class="wrap" style="max-width:420px">
<a class="back" href="../">← Volver al inicio</a>
<h1>Iniciar sesión</h1>
<div class="card">
<?php if ($error): ?><p class="err"><?= htmlspecialchars($error) ?></p><?php endif; ?>
<form method="post" id="login">
  <label for="usuario">Usuario</label><input id="usuario" name="usuario" value="<?= htmlspecialchars($_POST['usuario'] ?? '') ?>" autofocus>
  <label for="clave">Contraseña</label><input id="clave" name="clave" type="password">
  <p><button class="btn" style="width:100%">Entrar</button></p>
</form>
<p class="sub" style="font-size:.85rem">Prueba: <code>admin / admin123</code> o <code>maria / maria2024</code></p>
</div></div>
<script src="script.js"></script></body></html>
