CREATE DATABASE IF NOT EXISTS pwatarea3 CHARACTER SET utf8mb4;
USE pwatarea3;
CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario VARCHAR(50) NOT NULL UNIQUE,
  nombre VARCHAR(100) NOT NULL,
  clave_hash VARCHAR(255) NOT NULL
);
-- Claves: admin -> admin123 , maria -> maria2024  (generadas con password_hash)
INSERT IGNORE INTO usuarios (usuario, nombre, clave_hash) VALUES
('admin', 'Administrador', '$2y$10$tkqckzhUkhQe.2kmWAZndOVaKw9BihlzkhtEAXG27v//oUvo8gTmS'),
('maria', 'María Pérez',  '$2y$10$zjWDvnyeLTp5yVogJI7Go.GBi2UvsHg0xBvtiXchy96qxW/npj7nq');
