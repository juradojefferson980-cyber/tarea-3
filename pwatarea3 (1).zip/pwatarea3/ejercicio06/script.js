// Validación básica en el navegador antes de enviar el login.
document.getElementById('login').addEventListener('submit', e => {
  const u = e.target.usuario.value.trim(), c = e.target.clave.value;
  if (!u || !c) { e.preventDefault(); alert('Completa usuario y contraseña.'); }
});
