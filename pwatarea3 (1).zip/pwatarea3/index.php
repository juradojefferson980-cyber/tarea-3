<?php
// Página principal: presentación y menú con enlaces a cada ejercicio.
$ejercicios = [
  'ejercicio01' => ['Menú desplegable',        'HTML + CSS + JavaScript + PHP'],
  'ejercicio02' => ['Formulario de contacto',  'Validación con JavaScript y PHP'],
  'ejercicio03' => ['Contador de visitas',     'Variable global y persistencia en PHP'],
  'ejercicio04' => ['Juego de adivinanzas',    'PHP (sesión) + JavaScript (fetch)'],
  'ejercicio05' => ['Galería de imágenes',     'PHP lee el directorio + CSS Grid'],
  'ejercicio06' => ['Sistema de login',        'PHP, sesiones, arreglo de usuarios y MySQL opcional'],
];
?>
<!DOCTYPE html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Tarea 3 – HTML, CSS, JavaScript y PHP</title>
<link rel="stylesheet" href="style.css">
<style>.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px;margin-top:20px}
.item{display:block;text-decoration:none;color:inherit;background:var(--card);border-radius:14px;padding:18px;border:1px solid #334155;transition:.2s}
.item:hover{transform:translateY(-4px);border-color:var(--ac)}.num{color:var(--ac);font-weight:800;font-size:.85rem}
.item h2{margin:4px 0;font-size:1.15rem}.item p{margin:0;color:var(--mu);font-size:.9rem}</style></head>
<body><div class="wrap">
<h1>Tarea 3 · Desarrollo web</h1>
<p class="sub">Ejercicios de HTML, CSS, JavaScript y PHP · Programación Web Avanzada</p>
<div class="card"><p>Selecciona un ejercicio del menú. Cada uno vive en su propio directorio con su <code>index.php</code>, hoja de estilos y scripts.</p>
<p>Estudiante: <strong>Jefferson Jurado</strong> · Año <?= date('Y') ?></p></div>
<nav class="grid">
<?php $n = 1; foreach ($ejercicios as $dir => [$titulo, $desc]): ?>
  <a class="item" href="<?= $dir ?>/"><span class="num">EJERCICIO <?= sprintf('%02d', $n++) ?></span><h2><?= htmlspecialchars($titulo) ?></h2><p><?= htmlspecialchars($desc) ?></p></a>
<?php endforeach; ?>
</nav></div></body></html>
